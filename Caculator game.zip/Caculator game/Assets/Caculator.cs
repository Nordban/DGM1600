﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Caculator : MonoBehaviour { 
    public InputField rightInput;
    public InputField leftInput;
    public Text answer;
    public Text test;
    public float rest;
   	// Use this for initialization
	void Start () {

         
        
    }
    
     public void Add()
    {
        rest = float.Parse(leftInput.text) + float.Parse(rightInput.text);
        answer.text = rest.ToString();
        print(rest.ToString());
        

    }
    public void Subtract()
    {
        rest = float.Parse(leftInput.text) - float.Parse(rightInput.text);
        answer.text = rest.ToString();
        print(rest.ToString());
    }
    public void Multiply()
    {
        rest = float.Parse(leftInput.text) * float.Parse(rightInput.text);
        answer.text = rest.ToString();
        print(rest.ToString());
    }
    public void Devide()
    {
        rest = float.Parse(leftInput.text) / float.Parse(rightInput.text);
        answer.text = rest.ToString();
        print(rest.ToString());
    }

   
	// Update is called once per frame
	void Update () {
        
    }
    
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class TogleButtons : MonoBehaviour{
    public string answer;
    public string num;
    public float numF;
    public float answerF;
    public GameObject cube;
    public Text target;
    public Text ans;
    public string value;
    public string value2;
    // Use this for initialization

    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        DestroyObj();
	}
    public void DestroyObj()
    {
        cube.GetComponentInChildren<TextMesh>().text = value;
        value = target.ToString();
        value2 = ans.ToString();
        if(value == value2)
        {
            Destroy(cube);
        }
    }
    public void Toggle()
    {
       // num = 
        //numF = float.Parse(num);
        answerF = float.Parse(answer);
        if (numF == answerF)
        {

        }
    }
}

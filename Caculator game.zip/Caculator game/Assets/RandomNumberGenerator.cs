﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RandomNumberGenerator : MonoBehaviour {
    public string target;
    public int randNum;
    public GameObject numObject = null;
    public GameObject answer;
    public string ans;
    // Use this for initialization
    void MakeRandNum()
    {
        randNum = Random.Range(1, 200);
        target = randNum.ToString();
        numObject.GetComponent<TextMesh>().text = target;
        
        print(target.ToString());
    }
    void Start () {

        MakeRandNum();
	}
	
	// Update is called once per frame
	void Update () {
       
      }
	}

